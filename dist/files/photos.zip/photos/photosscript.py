from PIL import Image

def replace_white_pixels(input_image_path, replacement_image_path, output_image_path):
    # Wczytaj oryginalne i zastępcze zdjęcia
    original_image = Image.open(input_image_path).convert("RGBA")
    replacement_image = Image.open(replacement_image_path)

    # Pobierz dane o wymiarach obrazów
    width, height = original_image.size

    # Przeiteruj przez piksele obrazu
    for x in range(width):
        for y in range(height):
            # Pobierz kolor piksela w oryginalnym obrazie
            pixel_color = original_image.getpixel((x, y))

            # Sprawdź czy każda składowa koloru w pikselu jest równa 255 (biały)
            if all(c == 255 for c in pixel_color[:3]):
                # Zastąp piksel z obrazu zastępczego
                replacement_color = replacement_image.getpixel((x % replacement_image.width, y % replacement_image.height))
                original_image.putpixel((x, y), replacement_color)

    # Konwertuj obraz na tryb RGB przed zapisaniem jako JPEG
    rgb_image = original_image.convert("RGB")
    rgb_image.save(output_image_path)

if __name__ == "__main__":
    # Podaj nazwy plików zdjęć
    input_image = "D:/szkola/informatyka/git/Informatyka-Wlasna/photos/obraz_do_zamiany.jpg"
    replacement_image = "D:/szkola/informatyka/git/Informatyka-Wlasna/photos/wybrane_zdjecie.jpg"
    output_image = "D:/szkola/informatyka/git/Informatyka-Wlasna/photos/wynikowe_zdjecie.png"

    # Wywołaj funkcję do zamiany białych pikseli
    replace_white_pixels(input_image, replacement_image, output_image)
